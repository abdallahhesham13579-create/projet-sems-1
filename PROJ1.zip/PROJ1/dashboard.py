# dashboard.py

import tkinter as tk
from tkinter import ttk
from PROJ1 import (
    get_web_services,
    get_temperatures,
    get_power_status,
    get_memory_info,
    get_disk_info,
    get_processes,
    get_hostname,
    get_current_time,
    get_uptime
)



class SystemDashboard(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("System Monitor Dashboard")
        self.geometry("900x600")

        self.text = tk.Text(self, font=("Arial", 11))
        self.text.pack(fill="both", expand=True)
        self.text.tag_configure("header", font=("Consolas", 16, "bold"))
        self.update_dashboard()

    def update_dashboard(self):
        self.text.delete("1.0", tk.END)
        
        hostname=get_hostname()
        self.text.insert(tk.END, "hostname" + "\n" , "header")
        self.text.insert(tk.END, hostname + "\n" , "p")

        current_time = get_current_time()
        self.text.insert(tk.END, "current_time" + "\n" , "header")
        self.text.insert(tk.END, f"{current_time}\n", "p")

        current_uptime = get_uptime()
        self.text.insert(tk.END, "uptime" + "\n" , "header")
        self.text.insert(tk.END, f"{current_uptime}\n", "p")


        # Temperatures
        self.text.insert(tk.END, "=== Temperatures ===\n" , "header")
        for t in get_temperatures():
            self.text.insert(tk.END, f"{t[0]} : {t[1]}\n")
        self.text.insert(tk.END, "\n")

        # Power
        self.text.insert(tk.END, "=== Power Status ===\n" , "header")
        for name, val in get_power_status():
            self.text.insert(tk.END, f"{name}: {val}\n")
        self.text.insert(tk.END, "\n")

        # Memory
        self.text.insert(tk.END, "=== Memory ===\n" , "header") 
        for name, val in get_memory_info():
            self.text.insert(tk.END, f"{name}: {val}\n")
        self.text.insert(tk.END, "\n")

        # Disk
        self.text.insert(tk.END, "=== Disks ===\n" , "header")
        for mount, info in get_disk_info():
            self.text.insert(tk.END, f"{mount}: {info}\n")
        self.text.insert(tk.END, "\n")

        # Processes
        self.text.insert(tk.END, "=== Top Processes (CPU) ===\n", "header")
        for p in get_processes():
            self.text.insert(tk.END, f"{p}\n")

        # Web services
        self.text.insert(tk.END, "=== Web Services ===\n" , "header")
        for s in get_web_services():
            self.text.insert(tk.END, f"{s}\n")
        self.text.insert(tk.END, "\n")    

        # Refresh every 1000 ms
        self.after(1000, self.update_dashboard)


if __name__ == "__main__":
    app = SystemDashboard()
    app.mainloop()
