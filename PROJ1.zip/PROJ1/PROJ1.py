from datetime import datetime
from datetime import timedelta
import webbrowser
from pathlib import Path
import shutil
import subprocess
import socket
import http.client
import ssl
import re
from tkinter import * 
import time
import threading



# Get current date and time
def get_current_time():
    try:
     return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        print(f"Error getting time:")
        return "Error: Could not retrieve time"
current_time = get_current_time()
time_html = f"{current_time}"


def get_hostname():
    try: return Path("/proc/sys/kernel/hostname").read_text().strip()
    except Exception:
        print(f"Error getting hostname:")
        return "Error: Could not retrieve hostname"    
hostname = get_hostname()
hostname_html = f"{hostname}"
version = Path("/proc/version").read_text().strip()

def get_uptime():
    try:
        raw_uptime = Path("/proc/uptime").read_text().strip()
        total_seconds = int(float(raw_uptime.split()[0]))
        total_minutes, seconds = divmod(total_seconds, 60)
        hours, minutes = divmod(total_minutes, 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    except Exception:
        print(f"Error getting time:")
        return "Error: Could not retrieve time"
uptime = get_uptime()
uptime_html = f"{uptime}"



def get_temperatures():
    temps = []
    try:
        for zone in Path("/sys/class/thermal").iterdir():
            type_file = zone / "type"
            temp_file = zone / "temp"
            if not (type_file.exists() and temp_file.exists()):
                continue
            try:
                sensor = type_file.read_text().strip()
                temp = int(temp_file.read_text().strip()) / 1000
                temps.append((sensor, f"{temp:.1f}°C"))
            except Exception:
                temps.append((zone.name, "N/A"))
    except Exception:
        temps.append(("Thermal info", "Not available"))
    return temps
temps = get_temperatures()
temps_html = "<br>".join([f"{sensor}: {temp}" for sensor, temp in temps])

def get_power_status():
    power_info = []
    power_path = Path("/sys/class/power_supply")
    if not power_path.exists():
        return [("Power Info", "Not available")]

    for device in power_path.iterdir():
        status_file = device / "status"
        capacity_file = device / "capacity"
        online_file = device / "online"

        try:
            if status_file.exists():
                status = status_file.read_text().strip()
                power_info.append((device.name + " status", status))
            if capacity_file.exists():
                capacity = capacity_file.read_text().strip() + "%"
                power_info.append((device.name + " capacity", capacity))
            if online_file.exists():
                online = "Plugged in" if online_file.read_text().strip() == "1" else "Not plugged in"
                power_info.append((device.name + " online", online))
        except Exception:
            power_info.append((device.name, "Error reading info"))
    
    if not power_info:
        power_info.append(("Power Info", "Not available"))
    return power_info
power_status = get_power_status()
power_html = "<br>".join([f"{name}: {value}" for name, value in power_status])

def get_memory_info():
    meminfo = {}
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                parts = line.split(":")
                key = parts[0]
                value = parts[1].strip().split()[0]  # take numeric part only
                meminfo[key] = int(value)
    except Exception:
        return [("Memory Info", "Not available")]

    try:
        total = meminfo.get("MemTotal", 0)
        free = meminfo.get("MemFree", 0)
        cached = meminfo.get("Cached", 0)
        used = total - free - cached

        used_pct = used / total * 100 if total else 0
        free_pct = free / total * 100 if total else 0
        cache_pct = cached / total * 100 if total else 0

        return [
            ("Total", f"{total / 1024:.1f} MB"),
            ("Used", f"{used / 1024:.1f} MB ({used_pct:.1f}%)"),
            ("Free", f"{free / 1024:.1f} MB ({free_pct:.1f}%)"),
            ("Cached", f"{cached / 1024:.1f} MB ({cache_pct:.1f}%)")
        ]
    except Exception:
        return [("Memory Info", "Error calculating memory")]
memory_info = get_memory_info()
memory_html = "<br>".join([f"{k}: {v}" for k, v in memory_info])


def get_disk_info():
    disks_info = []

    # Check the list of mount points from /proc/mounts
    try:
        with open("/proc/mounts") as f:
            mounts = [line.split()[1] for line in f if line.startswith("/dev/")]
    except Exception:
        return [("Disk Info", "Not available")]

    seen = set()
    for mount in mounts:
        # Avoid duplicate mount points
        if mount in seen:
            continue
        seen.add(mount)
        try:
            usage = shutil.disk_usage(mount)
            total = usage.total / (1024 ** 3)  # bytes → GB
            used = usage.used / (1024 ** 3)
            free = usage.free / (1024 ** 3)
            used_pct = (used / total) * 100 if total else 0
            disks_info.append((
                mount,
                f"Total: {total:.1f} GB, Used: {used:.1f} GB ({used_pct:.1f}%), Free: {free:.1f} GB"
            ))
        except Exception:
            disks_info.append((mount, "Error reading usage"))
    
    if not disks_info:
        disks_info.append(("Disk Info", "No disks found"))
    
    return disks_info
disk_info = get_disk_info()
disk_html = "<br>".join([f"{mount}: {details}" for mount, details in disk_info])



def get_processes(limit=10):
    try:
        # Run 'ps' command to get top 10 processes by CPU usage
        result = subprocess.run(
            ["ps", "-eo", "pid,user,pcpu,pmem,comm", "--sort=-pcpu"],
            capture_output=True, text=True, check=True
        )
        lines = result.stdout.strip().split("\n")

        # First line is the header
        headers = lines[0].split()
        processes = []

        # Collect the next 'limit' processes
        for line in lines[1:limit+1]:
            parts = line.split(None, 4)
            if len(parts) == 5:
                pid, user, cpu, mem, name = parts
                processes.append({
                    "PID": pid,
                    "User": user,
                    "CPU": cpu,
                    "Memory": mem,
                    "Name": name
                })
        return processes
    except Exception as e:
        return [{"Error": str(e)}]

processes = get_processes(10)

process_rows = "".join(
    f"<tr><td>{p['PID']}</td><td>{p['User']}</td><td>{p['CPU']}</td>"
    f"<td>{p['Memory']}</td><td>{p['Name']}</td></tr>"
    for p in processes
)

def get_network_info():
    networks = []
    try:
        for iface in Path("/sys/class/net").iterdir():
            name = iface.name
            operstate = (iface / "operstate").read_text().strip()

            # Read statistics from /proc/net/dev
            with open("/proc/net/dev") as f:
                for line in f:
                    if name + ":" in line:
                        data = line.split(":")[1].split()
                        rx_bytes, tx_bytes = int(data[0]), int(data[8])
                        networks.append({
                            "Interface": name,
                            "Status": operstate,
                            "RX (KB)": f"{rx_bytes / 1024:.1f}",
                            "TX (KB)": f"{tx_bytes / 1024:.1f}",
                        })
                        break
    except Exception as e:
        networks.append({"Error": str(e)})
    return networks

network_info = get_network_info()

network_rows = "".join(
    f"<tr><td>{n['Interface']}</td><td>{n['Status']}</td>"
    f"<td>{n['RX (KB)']}</td><td>{n['TX (KB)']}</td></tr>"
    for n in network_info
)

def get_web_services():
    services = []
    ports = [80, 443]
    localhost = "127.0.0.1"

    for port in ports:
        # Check if port is open
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((localhost, port))
        result = sock.connect_ex((localhost, port))
        sock.close()

        if result != 0:
            services.append({
                "Port": port,
                "Status": "Closed",
                "Title": "-",
                "Favicon": "-",
                "Server": "-"
            })
            continue

        # Try to connect and fetch basic info
        try:
            if port == 443:
                context = ssl._create_unverified_context()
                conn = http.client.HTTPSConnection(localhost, port, timeout=2, context=context)
            else:
                conn = http.client.HTTPConnection(localhost, port, timeout=2)

            conn.request("GET", "/")
            response = conn.getresponse()
            headers = dict(response.getheaders())
            data = response.read(2048).decode(errors="ignore")  # read only the first part of HTML

            # Extract page title
            title_match = re.search(r"<title>(.*?)</title>", data, re.IGNORECASE | re.DOTALL)
            title = title_match.group(1).strip() if title_match else "No title"

            # Extract favicon link
            fav_match = re.search(r'rel=["\'](?:shortcut )?icon["\'][^>]*href=["\']([^"\']+)["\']', data, re.IGNORECASE)
            favicon = fav_match.group(1).strip() if fav_match else "None"

            server = headers.get("Server", "Unknown")

            services.append({
                "Port": port,
                "Status": "Open",
                "Title": title,
                "Favicon": favicon,
                "Server": server
            })

            conn.close()

        except Exception as e:
            services.append({
                "Port": port,
                "Status": "Open",
                "Title": f"Error: {e}",
                "Favicon": "-",
                "Server": "Unknown"
            })

    return services
web_services = get_web_services()

web_services_rows = "".join(
    f"<tr><td>{s['Port']}</td><td>{s['Status']}</td>"
    f"<td>{s['Title']}</td><td>{s['Favicon']}</td><td>{s['Server']}</td></tr>"
    for s in web_services
) 



template_path = "template.html" 
output_path = "report.html"      

try:

    template_string = Path(template_path).read_text()


    
    final_html = template_string.replace("{{time_html}}", time_html)
    final_html = final_html.replace("{{hostname_html}", hostname_html)
    final_html = final_html.replace("{{version}}", version)
    final_html = final_html.replace("{{uptime_html}}", uptime_html)
    final_html = final_html.replace("{{temps_html}}", temps_html)
    final_html = final_html.replace("{{power_html}}", power_html)
    final_html = final_html.replace("{{memory_html}}", memory_html)
    final_html = final_html.replace("{{disk_html}}", disk_html)
    final_html = final_html.replace("{{process_rows}}", process_rows)
    final_html = final_html.replace("{{network_rows}}", network_rows)
    final_html = final_html.replace("{{web_services_rows}}", web_services_rows)
    

    with open(output_path, "w") as file:
        file.write(final_html)


    webbrowser.open(f"{output_path}")
    
    print(f"HTML file '{output_path}' has been generated and opened in the browser.")

except FileNotFoundError:
    print(f"Error: The template file '{template_path}' was not found.")
except Exception as e:
    print(f"An error occurred: {e}")


